﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;
using System;
using System;
using System;
using System.IO;

namespace WpfApp5.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public string ProductDescription { get; set; } = string.Empty;
        public string ManufacturerName { get; set; } = string.Empty;
        public string SupplierName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string ProductUnit { get; set; } = string.Empty;
        public int StockQuantity { get; set; }
        public int Discount { get; set; }

        public string PhotoPath { get; set; } = "";

        public string FullPhotoPath
        {
            get
            {
                if (string.IsNullOrWhiteSpace(PhotoPath))
                    return "Images/picture.png";

                // Убираем Images\ если есть
                string fileName = PhotoPath.Replace("Images\\", "").Replace("Images/", "");
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", fileName);

                if (File.Exists(fullPath))
                    return fullPath;

                // Альтернативный вариант
                string fullPath2 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, PhotoPath.Replace("/", "\\"));
                if (File.Exists(fullPath2))
                    return fullPath2;

                return "Images/picture.png";
            }
        }

        public decimal FinalPrice => Price * (1 - Discount / 100m);
    }
}