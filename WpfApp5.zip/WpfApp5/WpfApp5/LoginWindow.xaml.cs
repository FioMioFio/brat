﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.OleDb;
using System.Windows;
using WpfApp5.Models;
using WpfApp5;

namespace WpfApp5
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            var window = new ProductsWindow(null);
            window.Show();
            Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text.Trim();
            string password = PasswordBox.Password;

            using (var connection = new OleDbConnection(AppDb.ConnectionString))
            using (var command = connection.CreateCommand())
            {
                command.CommandText = @"
SELECT UserId, RoleId, LastName, FirstName, MiddleName, Login, UserPassword
FROM Users
WHERE Login = ? AND UserPassword = ?";

                command.Parameters.AddWithValue("@p1", login);
                command.Parameters.AddWithValue("@p2", password);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    if (reader != null && reader.Read())
                    {
                        var user = new User
                        {
                            UserId = reader.GetInt32(0),
                            RoleId = reader.GetInt32(1),
                            LastName = reader.GetString(2),
                            FirstName = reader.GetString(3),
                            MiddleName = reader.GetString(4),
                            Login = reader.GetString(5),
                            UserPassword = reader.GetString(6)
                        };

                        var window = new ProductsWindow(user);
                        window.Show();
                        Close();
                        return;
                    }
                }
            }

            MessageBox.Show("Неверный логин или пароль.", "Ошибка входа",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}