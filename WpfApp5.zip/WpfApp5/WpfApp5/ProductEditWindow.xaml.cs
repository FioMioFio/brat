﻿using System;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using WpfApp5.Models;

namespace WpfApp5
{
    public partial class ProductEditWindow : Window
    {
        private readonly Product? _editingProduct;
        private string? _newImagePath;

        public ProductEditWindow(Product? product)
        {
            InitializeComponent();
            _editingProduct = product;

            LoadCategories();
            LoadManufacturers();

            if (product != null)
            {
                Title = "Редактирование товара";
                DeleteBtn.Visibility = Visibility.Visible;
                LoadProductData();
            }
            else
            {
                Title = "Добавление товара";
            }
        }

        private void LoadCategories()
        {
            try
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();
                    var cmd = new OleDbCommand("SELECT CategoryId, CategoryName FROM Categories", connection);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CategoryBox.Items.Add(new ComboBoxItem
                            {
                                Content = reader.GetString(1),
                                Tag = reader.GetInt32(0)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки категорий: {ex.Message}");
            }
        }

        private void LoadManufacturers()
        {
            try
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();
                    var cmd = new OleDbCommand("SELECT ManufacturerId, ManufacturerName FROM Manufacturers", connection);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ManufacturerBox.Items.Add(new ComboBoxItem
                            {
                                Content = reader.GetString(1),
                                Tag = reader.GetInt32(0)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки производителей: {ex.Message}");
            }
        }

        private void LoadProductData()
        {
            if (_editingProduct == null) return;

            ProductIdBox.Text = _editingProduct.ProductId.ToString();
            ProductNameBox.Text = _editingProduct.ProductName;
            DescriptionBox.Text = _editingProduct.ProductDescription;
            SupplierBox.Text = _editingProduct.SupplierName;
            PriceBox.Text = _editingProduct.Price.ToString();
            UnitBox.Text = _editingProduct.ProductUnit;
            QuantityBox.Text = _editingProduct.StockQuantity.ToString();
            DiscountBox.Text = _editingProduct.Discount.ToString();

            // Выбираем категорию
            foreach (ComboBoxItem item in CategoryBox.Items)
            {
                if (item.Content.ToString() == _editingProduct.CategoryName)
                {
                    CategoryBox.SelectedItem = item;
                    break;
                }
            }

            // Выбираем производителя
            foreach (ComboBoxItem item in ManufacturerBox.Items)
            {
                if (item.Content.ToString() == _editingProduct.ManufacturerName)
                {
                    ManufacturerBox.SelectedItem = item;
                    break;
                }
            }

            // Загружаем фото
            if (!string.IsNullOrEmpty(_editingProduct.PhotoPath) && File.Exists(_editingProduct.FullPhotoPath))
            {
                ProductImage.Source = new BitmapImage(new Uri(_editingProduct.FullPhotoPath));
            }
        }

        private void LoadImageBtn_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "Изображения|*.png;*.jpg;*.jpeg";

            if (dialog.ShowDialog() == true)
            {
                string imagesDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");
                if (!Directory.Exists(imagesDir))
                    Directory.CreateDirectory(imagesDir);

                string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(dialog.FileName);
                string newFilePath = Path.Combine(imagesDir, newFileName);
                File.Copy(dialog.FileName, newFilePath, true);

                // Удаляем старое фото
                if (_editingProduct != null && !string.IsNullOrEmpty(_editingProduct.PhotoPath))
                {
                    string oldPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _editingProduct.PhotoPath);
                    if (File.Exists(oldPath))
                        File.Delete(oldPath);
                }

                _newImagePath = $"Images/{newFileName}";
                ProductImage.Source = new BitmapImage(new Uri(newFilePath));
            }
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (string.IsNullOrWhiteSpace(ProductNameBox.Text))
            {
                MessageBox.Show("Введите наименование товара!");
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Введите корректную цену!");
                return;
            }

            if (!int.TryParse(QuantityBox.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Введите корректное количество!");
                return;
            }

            if (!int.TryParse(DiscountBox.Text, out int discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Введите скидку от 0 до 100!");
                return;
            }

            try
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();

                    if (_editingProduct == null)
                    {
                        // Добавление
                        string query = @"
                            INSERT INTO Products (ProductName, CategoryId, ProductDescription, ManufacturerId, 
                                                 SupplierName, Price, ProductUnit, StockQuantity, Discount, PhotoPath)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                        using (var cmd = new OleDbCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@p1", ProductNameBox.Text);
                            cmd.Parameters.AddWithValue("@p2", ((ComboBoxItem)CategoryBox.SelectedItem)?.Tag ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@p3", DescriptionBox.Text);
                            cmd.Parameters.AddWithValue("@p4", ((ComboBoxItem)ManufacturerBox.SelectedItem)?.Tag ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@p5", SupplierBox.Text);
                            cmd.Parameters.AddWithValue("@p6", price);
                            cmd.Parameters.AddWithValue("@p7", UnitBox.Text);
                            cmd.Parameters.AddWithValue("@p8", quantity);
                            cmd.Parameters.AddWithValue("@p9", discount);
                            cmd.Parameters.AddWithValue("@p10", _newImagePath ?? (object)DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Товар добавлен!");
                    }
                    else
                    {
                        // Обновление
                        string query = @"
                            UPDATE Products SET ProductName=?, CategoryId=?, ProductDescription=?, ManufacturerId=?,
                                              SupplierName=?, Price=?, ProductUnit=?, StockQuantity=?, Discount=?, PhotoPath=?
                            WHERE ProductId=?";
                        using (var cmd = new OleDbCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@p1", ProductNameBox.Text);
                            cmd.Parameters.AddWithValue("@p2", ((ComboBoxItem)CategoryBox.SelectedItem)?.Tag ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@p3", DescriptionBox.Text);
                            cmd.Parameters.AddWithValue("@p4", ((ComboBoxItem)ManufacturerBox.SelectedItem)?.Tag ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@p5", SupplierBox.Text);
                            cmd.Parameters.AddWithValue("@p6", price);
                            cmd.Parameters.AddWithValue("@p7", UnitBox.Text);
                            cmd.Parameters.AddWithValue("@p8", quantity);
                            cmd.Parameters.AddWithValue("@p9", discount);
                            cmd.Parameters.AddWithValue("@p10", _newImagePath ?? _editingProduct.PhotoPath);
                            cmd.Parameters.AddWithValue("@p11", _editingProduct.ProductId);
                            cmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Товар обновлен!");
                    }
                }
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_editingProduct == null) return;

            // Проверка наличия в заказах
            using (var connection = new OleDbConnection(AppDb.ConnectionString))
            {
                connection.Open();
                var cmd = new OleDbCommand("SELECT COUNT(*) FROM OrderItems WHERE ProductId=?", connection);
                cmd.Parameters.AddWithValue("@p1", _editingProduct.ProductId);
                int count = (int)cmd.ExecuteScalar();
                if (count > 0)
                {
                    MessageBox.Show("Нельзя удалить товар, который есть в заказах!");
                    return;
                }
            }

            if (MessageBox.Show($"Удалить товар \"{_editingProduct.ProductName}\"?", "Подтверждение",
                MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();
                    var cmd = new OleDbCommand("DELETE FROM Products WHERE ProductId=?", connection);
                    cmd.Parameters.AddWithValue("@p1", _editingProduct.ProductId);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Товар удален!");
                DialogResult = true;
                Close();
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}