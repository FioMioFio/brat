﻿using System;
using System.Data.OleDb;
using System.IO;

using System.Data.OleDb;

namespace WpfApp5
{
    public static class AppDb
    {
        public static string ConnectionString =>
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=bdshka.accdb;Persist Security Info=False;";
    }
}