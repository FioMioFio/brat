﻿using System.Configuration;
using System.Data;
using System.Windows;
using System.Windows;

namespace WpfApp5
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            // Можно добавить инициализацию подключения здесь
        }
    }
}
