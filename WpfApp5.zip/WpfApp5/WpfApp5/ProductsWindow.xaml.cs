﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using WpfApp5.Models;

namespace WpfApp5
{
    public partial class ProductsWindow : Window
    {
        private readonly User? _currentUser;
        private List<Product> _allProducts = new List<Product>();
        private bool _isEditFormOpen = false;

        public ProductsWindow(User? user)
        {
            InitializeComponent();
            _currentUser = user;

            if (_currentUser != null)
                UserNameText.Text = _currentUser.FullName;
            else
                UserNameText.Text = "Гость";

            ConfigureAccessRights();
            LoadProducts();
        }

        private void ConfigureAccessRights()
        {
            string role = GetUserRole();

            // Кнопка выхода для гостя и клиента
            LogoutBtn.Visibility = (role == "Guest" || role == "Client") ? Visibility.Visible : Visibility.Collapsed;

            // Кнопка добавления и подсказка для админа
            bool isAdmin = (role == "Admin");
            AddProductBtn.Visibility = isAdmin ? Visibility.Visible : Visibility.Collapsed;
            AdminHint.Visibility = isAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private string GetUserRole()
        {
            if (_currentUser == null) return "Guest";
            try
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();
                    var cmd = new OleDbCommand("SELECT RoleName FROM Roles WHERE RoleId = ?", connection);
                    cmd.Parameters.AddWithValue("@p1", _currentUser.RoleId);
                    var result = cmd.ExecuteScalar();
                    string roleName = result?.ToString() ?? "Guest";

                    // Преобразуем русские названия в английские для кода
                    if (roleName == "Администратор") return "Admin";
                    if (roleName == "Менеджер") return "Manager";
                    if (roleName == "Авторизированный клиент") return "Client";

                    return roleName;
                }
            }
            catch { return "Guest"; }
        }

        private void LoadProducts()
        {
            _allProducts.Clear();
            ProductsPanel.Children.Clear();

            try
            {
                using (var connection = new OleDbConnection(AppDb.ConnectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT
                            p.ProductId, p.ProductName, 
                            c.CategoryName, 
                            p.ProductDescription,
                            m.ManufacturerName, 
                            s.SupplierName, 
                            p.Price, 
                            p.ProductUnit,
                            p.StockQuantity, 
                            p.Discount, 
                            p.PhotoPath
                        FROM (((Products p
                            LEFT JOIN Categories c ON p.CategoryId = c.CategoryId)
                            LEFT JOIN Manufacturers m ON p.ManufacturerId = m.ManufacturerId)
                            LEFT JOIN Suppliers s ON p.SupplierId = s.SupplierId)";

                    using (var command = new OleDbCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                ProductId = reader.GetInt32(0),
                                ProductName = reader.GetString(1),
                                CategoryName = reader.IsDBNull(2) ? "Без категории" : reader.GetString(2),
                                ProductDescription = reader.IsDBNull(3) ? "" : reader.GetString(3),
                                ManufacturerName = reader.IsDBNull(4) ? "Не указан" : reader.GetString(4),
                                SupplierName = reader.IsDBNull(5) ? "Не указан" : reader.GetString(5),
                                Price = reader.GetDecimal(6),
                                ProductUnit = reader.GetString(7),
                                StockQuantity = reader.GetInt32(8),
                                Discount = reader.GetInt32(9),
                                PhotoPath = reader.IsDBNull(10) ? "" : reader.GetString(10)
                            };
                            _allProducts.Add(product);
                            ProductsPanel.Children.Add(CreateProductCard(product));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }

        private Border CreateProductCard(Product product)
        {
            var border = new Border
            {
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(1),
                Margin = new Thickness(0, 0, 0, 12),
                Padding = new Thickness(10),
                Cursor = System.Windows.Input.Cursors.Hand
            };

            // Подсветка
            if (product.StockQuantity == 0)
                border.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#87CEFA"));
            else if (product.Discount > 12)
                border.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F4A460"));
            else
                border.Background = Brushes.White;

            // Двойной клик для админа (редактирование)
            string role = GetUserRole();
            if (role == "Admin")
            {
                border.MouseLeftButtonDown += (s, e) =>
                {
                    if (e.ClickCount == 2) // Двойной клик
                    {
                        OpenEditWindow(product);
                    }
                };
            }

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(220) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });

            // Фото
            var imageBorder = new Border
            {
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(1),
                Width = 200,
                Height = 160,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            var image = new Image
            {
                Source = GetImage(product.FullPhotoPath),
                Stretch = Stretch.UniformToFill
            };
            imageBorder.Child = image;
            Grid.SetColumn(imageBorder, 0);
            grid.Children.Add(imageBorder);

            // Информация
            var infoPanel = new StackPanel { Margin = new Thickness(12, 0, 12, 0) };
            Grid.SetColumn(infoPanel, 1);

            infoPanel.Children.Add(new TextBlock
            {
                Text = $"{product.CategoryName} | {product.ProductName}",
                FontSize = 18,
                FontWeight = FontWeights.Bold
            });
            infoPanel.Children.Add(new TextBlock
            {
                Text = product.ProductDescription,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 10, 0, 0),
                MaxHeight = 60
            });
            infoPanel.Children.Add(new TextBlock
            {
                Text = $"Производитель: {product.ManufacturerName}",
                Margin = new Thickness(0, 6, 0, 0)
            });
            infoPanel.Children.Add(new TextBlock
            {
                Text = $"Поставщик: {product.SupplierName}",
                Margin = new Thickness(0, 6, 0, 0)
            });

            var pricePanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
            pricePanel.Children.Add(new TextBlock { Text = "Цена: ", FontWeight = FontWeights.Bold });

            // Если есть скидка - перечеркиваем
            if (product.Discount > 0)
            {
                var oldPrice = new TextBlock
                {
                    Text = $"{product.Price:N2} ₽",
                    Foreground = Brushes.Red
                };
                oldPrice.TextDecorations = TextDecorations.Strikethrough;
                pricePanel.Children.Add(oldPrice);
                pricePanel.Children.Add(new TextBlock { Text = " → ", Margin = new Thickness(5, 0, 5, 0) });
                pricePanel.Children.Add(new TextBlock
                {
                    Text = $"{product.FinalPrice:N2} ₽",
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#28A745")),
                    FontWeight = FontWeights.Bold
                });
            }
            else
            {
                pricePanel.Children.Add(new TextBlock { Text = $"{product.Price:N2} ₽" });
            }
            infoPanel.Children.Add(pricePanel);

            infoPanel.Children.Add(new TextBlock
            {
                Text = $"Единица: {product.ProductUnit}",
                Margin = new Thickness(0, 6, 0, 0)
            });
            infoPanel.Children.Add(new TextBlock
            {
                Text = $"Остаток: {product.StockQuantity} шт",
                Margin = new Thickness(0, 6, 0, 0)
            });

            grid.Children.Add(infoPanel);

            // Скидка
            var discountPanel = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(discountPanel, 2);

            discountPanel.Children.Add(new TextBlock
            {
                Text = "Скидка",
                HorizontalAlignment = HorizontalAlignment.Center,
                FontWeight = FontWeights.Bold
            });
            discountPanel.Children.Add(new TextBlock
            {
                Text = $"{product.Discount}%",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center
            });

            grid.Children.Add(discountPanel);
            border.Child = grid;

            return border;
        }

        private ImageSource GetImage(string path)
        {
            try
            {
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                    return new BitmapImage(new Uri(path));
            }
            catch { }

            try
            {
                string defaultPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", "picture.png");
                if (File.Exists(defaultPath))
                    return new BitmapImage(new Uri(defaultPath));
            }
            catch { }

            return null;
        }

        private void OpenEditWindow(Product product)
        {
            if (_isEditFormOpen)
            {
                MessageBox.Show("Форма редактирования уже открыта!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var editWindow = new ProductEditWindow(product);
            editWindow.Owner = this;
            _isEditFormOpen = true;
            editWindow.Closed += (s, args) =>
            {
                _isEditFormOpen = false;
                LoadProducts();
            };
            editWindow.ShowDialog();
        }

        private void AddProductBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_isEditFormOpen)
            {
                MessageBox.Show("Форма редактирования уже открыта!", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var editWindow = new ProductEditWindow(null);
            editWindow.Owner = this;
            _isEditFormOpen = true;
            editWindow.Closed += (s, args) =>
            {
                _isEditFormOpen = false;
                LoadProducts();
            };
            editWindow.ShowDialog();
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
            Close();
        }
    }
}